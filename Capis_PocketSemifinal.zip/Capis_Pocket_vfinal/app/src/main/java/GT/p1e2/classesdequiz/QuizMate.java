package GT.p1e2.classesdequiz;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import GT.p1e2.R;
import GT.p1e2.variables_g;


public class QuizMate extends Fragment {

    ImageView im1;
    TextView txt1, txt3, txt2, txt4, txt5;
    ProgressBar pg1;
    RadioGroup rg1;
    RadioButton rb1;
    RadioButton rb2;
    RadioButton rb3;
    RadioButton rb4;

    Button btnR, btnO;
    int a = 1, x = 0, j = 0, m = 1;
    int w;

    Handler h = new Handler();

    public QuizMate() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //Para bloquear el boton de atras
        requireActivity().getOnBackPressedDispatcher().addCallback(getViewLifecycleOwner(), new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // sobreescribiendo el metodo para bloquear
            }
        });
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_quiz_mate, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        im1 = view.findViewById(R.id.im1);
        txt1 = view.findViewById(R.id.txt1);
        txt5 = view.findViewById(R.id.txtNPreg);
        pg1 = view.findViewById(R.id.pg1);
        rg1 = view.findViewById(R.id.rg1);
        rb1 = view.findViewById(R.id.rb1);
        rb2 = view.findViewById(R.id.rb2);
        rb3 = view.findViewById(R.id.rb3);
        rb4 = view.findViewById(R.id.rb4);

        PrimerP();

        rb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click();
            }
        });
        rb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click();
            }
        });

        rb3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click();
            }
        });

        rb4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click();
            }
        });
    }

    public void click() {
        if (rb1.isChecked()) {
            a++;
            Respuestas();
            barra();
            cont();
            rg1.clearCheck();
        } else if (rb2.isChecked()) {
            a++;
            Respuestas();
            barra();
            cont();
            rg1.clearCheck();
        } else if (rb3.isChecked()) {
            a++;
            Respuestas();
            barra();
            cont();
            rg1.clearCheck();
        } else if (rb4.isChecked()) {
            a++;
            Respuestas();
            barra();
            cont();
            rg1.clearCheck();
        }
        if (a == 11) {
            String j = String.valueOf(w);
            //txt3.setText("sw");
            dialogShow();
        }
    }

    public void preguntas() {
        //x = x + 1;
        //txt1.setText("Pregunta " + x);
        numPregunta();
        x++;
        if (x == 1) {
            txt1.setText("¿Cuál es el valor de ''x'' en la ecuación 2x+3 = 11?");
        } else if (x == 2) {
            txt1.setText("¿Cuál es la fórmula del área de un triángulo?");
        } else if (x == 3) {
            txt1.setText("¿Qué número es un número primo?");
        } else if (x == 4) {
            txt1.setText(". ¿Cuál es el resultado de |−8|?");
        } else if (x == 5) {
            txt1.setText("¿Cuánto es (3x)(2x)?");
        } else if (x == 6) {
            txt1.setText("¿Cuál es el valor de π (pi) aproximado a dos decimales?");
        } else if (x == 7) {
            txt1.setText("¿Qué representa la pendiente en una recta?");
        } else if (x == 8) {
            txt1.setText("¿Cuál es el mínimo común múltiplo de 4 y 6?");
        } else if (x == 9) {
            txt1.setText("¿Cuál es el resultado de (x + 2)(x − 2)?");
        }
    }

    public void Respuestas() {
        if (a == 2) {
            preguntas();
            rb1.setText("3");
            rb2.setText("4");
            rb3.setText("5");
            rb4.setText("6");
        } else if (a == 3) {
            preguntas();
            rb1.setText("base × altura");
            rb2.setText("lado × lado");
            rb3.setText("(base × altura) / 2");
            rb4.setText("(base + altura) / 2");
        } else if (a == 4) {
            preguntas();
            rb1.setText("9");
            rb2.setText("21");
            rb3.setText("15");
            rb4.setText("7");
        } else if (a == 5) {
            preguntas();
            rb1.setText("8");
            rb2.setText("0");
            rb3.setText("-8");
            rb4.setText("1");
        } else if (a == 6) {
            preguntas();
            rb1.setText("6x");
            rb2.setText("6x²");
            rb3.setText("5x²");
            rb4.setText("x⁶");
        } else if (a == 7) {
            preguntas();
            rb1.setText("3.00");
            rb2.setText("3.50");
            rb3.setText("3.14");
            rb4.setText("3.41");
        } else if (a == 8) {
            preguntas();
            rb1.setText("El ancho de la recta");
            rb2.setText("La longitud total");
            rb3.setText("El punto de intersección con el eje Y");
            rb4.setText("La inclinación o razón de cambio");
        } else if (a == 9) {
            preguntas();
            rb1.setText("12");
            rb2.setText("24");
            rb3.setText("6");
            rb4.setText("8");
        } else if (a == 10) {
            preguntas();
            rb1.setText("x² + 4");
            rb2.setText("x² − 4");
            rb3.setText("x² − 2");
            rb4.setText("x² − 2x + 4");
        }
    }

    public void PrimerP() {
        rb1.setText("18");
        rb2.setText("14");
        rb3.setText("12");
        rb4.setText("24");
    }

    public void cont() {
        if (a > 0 && a < 12) {
            j++;
            if (j == 1) {//1
                if (rb1.isChecked()) {
                    w = w + 1;
                } else {
                    w = w + 0;
                }
            } else if (j == 2) {//2
                if (rb2.isChecked()) {
                    w = w + 1;
                } else {
                    w = w + 0;
                }
            } else if (j == 3) {//3
                if (rb3.isChecked()) {
                    w = w + 1;
                } else {
                    w = w + 0;
                }
            } else if (j == 4) {//4
                if (rb4.isChecked()) {
                    w = w + 1;
                } else {
                    w = w + 0;
                }
            } else if (j == 5) {//5
                if (rb1.isChecked()) {
                    w = w + 1;
                } else {
                    w = w + 0;
                }
            } else if (j == 6) {//6
                if (rb2.isChecked()) {
                    w = w + 1;
                } else {
                    w = w + 0;
                }
            } else if (j == 7) {//7
                if (rb3.isChecked()) {
                    w = w + 1;
                } else {
                    w = w + 0;
                }
            } else if (j == 8) {//8
                if (rb4.isChecked()) {
                    w = w + 1;
                } else {
                    w = w + 0;
                }
            } else if (j == 9) {//9
                if (rb1.isChecked()) {
                    w = w + 1;
                } else {
                    w = w + 0;
                }
            } else if (j == 10) {//10
                if (rb2.isChecked()) {
                    w = w + 1;
                } else {
                    w = w + 0;
                }
            }
        }
    }

    public void barra() {
        pg1.setMax(100);
        new Thread(new Runnable() {
            @Override
            public void run() {
                pg1.setProgress(pg1.getProgress() + 10);
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        if (pg1.getProgress() < 110) {
                            //Toast.makeText(getActivity(), "Barra llena" + ": Punt: " + w,Toast.LENGTH_LONG).show();
                            //pgBar.setProgress(0);
                        }
                    }
                });
                try {
                    //Thread.sleep(1000);
                } catch (Exception e) {
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG);
                }
            }
        }
        ).start();
    }

    public void dialogShow() {
        String j = String.valueOf(w);
        AlertDialog.Builder b = new AlertDialog.Builder(requireContext());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View v = inflater.inflate(R.layout.resultado, null);

        txt2 = v.findViewById(R.id.txt2);
        txt3 = v.findViewById(R.id.txt3);
        txt4 = v.findViewById(R.id.txt4);

        txt2.setText("Quiz Matematico");
        txt3.setText(j + " /10");
        txt4.setText("¡Felicidades!");
        btnR = v.findViewById(R.id.btnReg);
        btnO = v.findViewById(R.id.btnOk);
        TextView txtDesbloqueo;
        txtDesbloqueo=v.findViewById(R.id.textObjeto);
        if (w==10){
            Log.i("objeto","si ejecuta");
            txtDesbloqueo.setVisibility(View.VISIBLE);
            variables_g v1=new variables_g(requireContext());
            v1.g_valor("Mat");
        }


        b.setView(v);

        AlertDialog al = b.create();
        al.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        al.setCancelable(false);

        btnR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                al.cancel();
                Cambiar(new QuizMate());
            }
        });
        btnO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                al.cancel();
                Cambiar(new MenuQuiz());
            }
        });
        Invisible();
        al.show();
    }

    public void Cambiar(Fragment f) {
        FragmentTransaction ft = getParentFragmentManager().beginTransaction();
        ft.replace(R.id.HojaPrincipal, f).commit();
    }

    public void Invisible(){
        View v = new View(requireContext());
        im1.setVisibility(v.GONE);
        rg1.setVisibility(v.GONE);
        pg1.setVisibility(v.GONE);
        txt1.setVisibility(v.GONE);
        txt5.setVisibility(v.GONE);
    }

    public void numPregunta(){
        m++;
        if(m == 2){
            txt5.setText("Pregunta " + a);
        } else if (m == 3) {
            txt5.setText("Pregunta " + a);
        } else if (m==4) {
            txt5.setText("Pregunta " + a);
        } else if (m==5) {
            txt5.setText("Pregunta " + a);
        } else if (m==6) {
            txt5.setText("Pregunta " + a);
        } else if (m==7) {
            txt5.setText("Pregunta " + a);
        } else if (m==8) {
            txt5.setText("Pregunta " + a);
        } else if (m==9) {
            txt5.setText("Pregunta " + a);
        } else if (m==10) {
            txt5.setText("Pregunta " + a);
        }
    }
}