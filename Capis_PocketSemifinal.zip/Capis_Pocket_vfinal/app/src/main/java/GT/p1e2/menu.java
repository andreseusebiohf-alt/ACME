package GT.p1e2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import GT.p1e2.classesdequiz.Principal;

public class menu extends AppCompatActivity {

    private ImageView imagen,capibaraimagen;
    int gt=1, g=0, gt2;
    int nc=0, vc=0;
    private View vcolicion;
    //valores de localizacion de la imagen
    private float dx,dy;
    //valores de localizacion del inicio
    private float fx,fy;
    TextView nombre;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_menu);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });

        nombre=findViewById(R.id.textonombre);
        //metodo para comprobar si esta usando un gorro el capibara
        capibaraimagen=findViewById(R.id.capibara);
        capibaraimagen.setImageResource(R.drawable.capiimg);
        comprobacion();
        //instancia de la clase con los valores guardados
        variables_g g1=new variables_g(this);
        // iniciar el class que da una cantidad de acomida por defecto
        g1.iniciopredeterminado();
        //inicializacion de la barra de progreso y el texto
        barradeprogreso(0);
        resbar();
        mus();
        metodonombre();

        imagen = findViewById(R.id.comida);
        imagen.setImageResource(R.drawable.imgsincomida);
        vcolicion = findViewById(R.id.colicion);

        //guardado de los valores iniciales de localizacion
        imagen.post(new Runnable() {
            @Override
            public void run() {
               fx=imagen.getX();
               fy=imagen.getY();
            }
        });

        //metodo que permite arrastrar la imagen
        imagen.setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint({"ClickableViewAccessibility", "WrongViewCast"})
            @Override
            public boolean onTouch(View v, MotionEvent event) {
               //switch que detecta la accion hecha
                switch (event.getAction())
                {
                    case MotionEvent.ACTION_DOWN:
                        dx= v.getX() - event.getRawX();
                        dy= v.getY() - event.getRawY();
                        gt2=0;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        v.setX((event.getRawX()+dx));
                        v.setY((event.getRawY()+dy));
                        //if que comprueba si v esta en colicion con el view y regresa la imagen a su localizacion original
                        if(HC(v,vcolicion)){
                            v.setX(fx);
                            v.setY(fy);
                            gt2=1+gt2;
                            if(gt==gt2){
                                g=g1.o_ncomida("cd7");
                                g=g+vc;
                                g1.g_ncomida("cd7",g);
                                barradeprogreso(vc);
                                int nvalorc=g1.o_ncomida("cd"+String.valueOf(nc));
                                g1.g_ncomida("cd"+String.valueOf(nc),nvalorc-1);
                                ifcomida(false);
                            }
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        v.setX(fx);
                        v.setY(fy);
                        break;
                }
                return true;
            }
        });
    }
    private boolean HC(View view1,View view2){
        //comprueba si los view colicionan
        Rect rect1 = new Rect();
        view1.getGlobalVisibleRect(rect1);
        Rect rect2 = new Rect();
        view2.getGlobalVisibleRect(rect2);
        //si el valor el true colicionan
        return rect1.intersect(rect2);
    }

    public void ajustess(View view) {
        //abre el adialogfragment"ajustes"
          f_ajustes aju=new f_ajustes();
          aju.show(getSupportFragmentManager(),"Ajustes");
    }

    public void armarioo(View view) {
        armarioSombreros arm=new armarioSombreros();
        arm.show(getSupportFragmentManager(),"Armario");
    }

    public void cizq(View view) {
        if(nc>0){
            nc--;
        }
        ifcomida(true);
    }

    public void cder(View view) {
        if (nc<6){
            nc++;
        }
        ifcomida(false);
    }
     //en esta funcion hay un if que selecciona el tipo de comida
    public void ifcomida(boolean re_c){
        variables_g g1=new variables_g(this);
        //for que da una segunda vuelta para encontrar el valor correcto
        for (int i=0;i<=2;i++) {
            //if anidado que busca el valor correcto a seleccionar
            if (nc == 0) {
                imagen.setImageResource(R.drawable.imgsincomida);
                vc = 0;
            }
            if (nc == 1) {
               if (g1.o_ncomida("cd1")>0){
                   imagen.setImageResource(R.drawable.imgagua);
                   vc = 1;
               }else {
                   if (re_c == true) {
                       nc = 0;
                   } else {
                       nc = 2;
                   }
               }
            }
            if (nc == 2) {
                if (g1.o_ncomida("cd2")>0){
                    imagen.setImageResource(R.drawable.imgzanahoria);
                    vc = 3;
                }else {
                    if (re_c == true) {
                        nc = 1;
                    } else {
                        nc = 3;
                    }
                }
            }
            if (nc == 3) {
                if (g1.o_ncomida("cd3")>0){
                    int j=g1.o_ncomida("cd3");
                    imagen.setImageResource(R.drawable.imglechuga);
                    vc = 5;
                }else {
                    if (re_c == true) {
                        nc = 2;
                    } else {
                        nc = 4;
                    }
                }
            }
            if (nc == 4) {
                if (g1.o_ncomida("cd4")>0){
                    int j=g1.o_ncomida("cd4");
                    imagen.setImageResource(R.drawable.imgelote);
                    vc = 3;
                }else {
                    if (re_c == true) {
                        nc = 3;
                    } else {
                        nc = 5;
                    }
                }
            }
            if (nc == 5) {
                if (g1.o_ncomida("cd5")>0){
                    int j=g1.o_ncomida("cd5");
                    imagen.setImageResource(R.drawable.imgsandia);
                    vc = 5;
                }else {
                    if (re_c == true) {
                        nc = 4;
                    } else {
                        nc = 6;
                    }
                }
            }
            if (nc == 6) {
                if (g1.o_ncomida("cd6")>0){
                    int j=g1.o_ncomida("cd6");
                    imagen.setImageResource(R.drawable.imgplanta);
                    vc = 10;
                }else {
                    if (re_c == true) {
                        nc = 5;
                    } else {
                        nc = 0;
                    }
                }
            }

        }
    }
    public void juegoss(View view) {

        Intent i=new Intent(this, menujuegos.class);
        startActivity(i);
    }
    //barra de progreso que suma los valores de comidad dados
    public void barradeprogreso(int v){
        variables_g g1=new variables_g(this);
        ProgressBar barradep=findViewById(R.id.progressBar);
        barradep.setMax(70);
        barradep.setProgress(g1.o_ncomida("cd7")+v);
    }

 //funcion para disminuir la comida cada 2 min
    public void resbar() {
        Handler handler=new Handler();
        variables_g g1=new variables_g(this);
        ProgressBar barradep=findViewById(R.id.progressBar);
        barradep.setMax(70);
        int t=120000;
        ///p
        Runnable r =new Runnable() {
            @Override
            public void run() {
                barradep.setProgress(g1.o_ncomida("cd7")-1);
                g1.g_ncomida("cd7",g1.o_ncomida("cd7")-1);

                if (g1.o_ncomida("cd7")>0){
                    handler.postDelayed(this,t);
                }
            }
        };
        if (g1.o_ncomida("cd7")>0){
            handler.post(r);
        }
    }
    public void mus(){
        variables_g g1=new variables_g(this);
        audio au=new audio(this);
        if (g1.o_musica()==true){
            au.audio1(this);
        }
    }

    public void desafios(View view) {
        Intent r =new Intent(this, Principal.class);
        startActivity(r);
    }
    public void metodonombre(){
        variables_g g1=new variables_g(this);
        nombre.setText(g1.o_nombre());
    }

    public void comprobacion(){
        Log.i("menumensaje","metodo comprobacion");
        variables_g v1=new variables_g(this);

        if (v1.o_valor_g("llave1")){
            capibaraimagen.setImageResource(R.drawable.imgitca);
            Log.i("menumensaje","if");
        }
        if (v1.o_valor_g("llave2")){
            capibaraimagen.setImageResource(R.drawable.imgzelda);
            Log.i("menumensaje","if");
        }
        if (v1.o_valor_g("llave3")){
            capibaraimagen.setImageResource(R.drawable.imgluigi);
            Log.i("menumensaje","if");
        }
        if (v1.o_valor_g("llave4")){
            capibaraimagen.setImageResource(R.drawable.imgmario);
            Log.i("menumensaje","if");
        }if (v1.o_valor_g("llave5")){
            capibaraimagen.setImageResource(R.drawable.imgperu);
            Log.i("menumensaje","if");
        }if (v1.o_valor_g("llave6")){
            capibaraimagen.setImageResource(R.drawable.imgmexa);
            Log.i("menumensaje","if");
        }if (v1.o_valor_g("llave7")){
            capibaraimagen.setImageResource(R.drawable.imgwicked);
            Log.i("menumensaje","if");
        }
        if (v1.o_valor_g("llave8")){
            capibaraimagen.setImageResource(R.drawable.imgclash);
            Log.i("menumensaje","if");
        }
    }
}